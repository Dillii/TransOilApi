Для запуска приложения требуется -
1) Установленный PostgreSQL где-нибудь (нужна строка подключения)
2) Установленная 2022 Visual Studio (ну или более старая но с новыми пакетами, тут не уверен, не тестировал)


Запуск:
после открытия проекта, необходимо:
1) зайти в файл App.config проекта TrueCodeConsoleDataBase и ввести в тег с ключом - DefaultConnection занести в value ваше подключение к базе.
1) Открыть Package Manager Console
2) ввести команду - Add-Migration Initial
3) ввести команду - Update-Database

После этого можно запускать проект TrueCodeConsoleDataBase.
Проект TrueCodeConsoleLoader запускается без бубна.