﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrueCodeConsole
{
    internal class FileStreamLoader : IStreamLoader
    {
        public Stream GetStream()
        {
            return File.OpenRead("Test.txt");
        }
    }
}
