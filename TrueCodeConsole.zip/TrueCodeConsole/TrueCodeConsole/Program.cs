﻿// See https://aka.ms/new-console-template for more information




using Microsoft.Extensions.DependencyInjection;
using TrueCodeConsole;

var provider = StartUp.InitApp();

var streamLoader = provider.GetService<IStreamLoader>();

if (streamLoader == null) throw new Exception("Ошибка! - не подключён ни один источник данных!");
MessageReader.ReadMessages(streamLoader, '\n');
Console.ReadLine();
