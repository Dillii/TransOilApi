﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrueCodeConsole
{
    public static class MessageReader
    {
        /// <summary>
        /// Долго думал какой читальщик вам нужен, решил что бесконечный, вероятно ошибся..
        /// </summary>
        /// <param name="streamLoader"></param>
        /// <param name="delimeter"></param>
        public async static void ReadMessages(IStreamLoader streamLoader, char delimeter)
        {
            int byteAsInt;
            var messageBuilder = new StringBuilder();
            var decoder = Encoding.UTF8.GetDecoder();
            var nextChar = new char[1];

            using (var inputStream = streamLoader.GetStream())
            {
                while ((byteAsInt = inputStream.ReadByte()) != -1)
                {
                    var charCount = decoder.GetChars(new[] { (byte)byteAsInt }, 0, 1, nextChar, 0);
                    if (charCount == 0) continue;

                    if (nextChar[0] == delimeter)
                    {
                        //так и не понял, что нужно делать с результатом, поэтому просто вывожу его на консоль
                        Console.Write(messageBuilder.ToString());
                        Console.WriteLine();
                        await Task.Delay(100); //чтобы всё не пролетало за милисекунды
                        messageBuilder.Clear();
                    }
                    else
                        messageBuilder.Append(nextChar);

                }
            }
        }
    }
}
