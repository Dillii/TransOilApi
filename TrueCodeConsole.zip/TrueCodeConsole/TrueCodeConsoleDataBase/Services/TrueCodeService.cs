﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrueCodeConsoleDataBase.DataBase;

namespace TrueCodeConsoleDataBase.Services
{
    internal class TrueCodeService : ITrueCodeService
    {

        public void GetAllUsersWithTagValue(ITrueCodeContext dbContext)
        {
            Console.WriteLine("Введите значение тега");
            var tagValue = Console.ReadLine();
            Console.WriteLine("Введите название домена");
            var domain = Console.ReadLine();
            var resultTags = dbContext.Tags.Where(a => a.Value == tagValue).Include(b => b.Users);
            var result = resultTags.SelectMany(c => c.Users).Distinct().Where(d => d.Domain == domain);
            if (!result.Any()) Console.WriteLine("Не удалось найти ни одного подходящего пользователя!");
            foreach (var user in result)
                Console.WriteLine(user.ToString());
            Console.ReadLine();
        }

        public void GetAllUsersInDomain(ITrueCodeContext dbContext)
        {
            Console.WriteLine("Введите название домена");
            var domain = Console.ReadLine();
            Console.WriteLine("Введите размер страницы:");
            int pageSize;
            while (!int.TryParse(Console.ReadLine(), out pageSize))
            {
                // да тут вечный цикл если пользователю нечем заняться
            }
            int count = dbContext.Users.Where(a => a.Domain == domain).Count();
            if (count <= pageSize)
            {
                var result = dbContext.Users.Where(a => a.Domain == domain).Include(a => a.Tags).OrderBy(b => b.Name);
                foreach (var user in result)
                    Console.WriteLine(user.ToString());
                return;
            }
            int position = 0;
            while (true)
            {
                var result = dbContext.Users.Where(a => a.Domain == domain).OrderBy(b => b.Name).Skip(position).Take(pageSize);
                foreach (var user in result)
                    Console.WriteLine(user.ToString());
                if (result.Count() < pageSize) return;
                Console.WriteLine("Следующая страница? Да | Нет ?");
                var answer = Console.ReadLine();
                //слишком часто вбивал lf
                if (answer?.ToLower() != "да" && answer?.ToLower() != "ok" && answer?.ToLower() != "lf") return;
                position = position + pageSize;
            }
        }

        public void GetUserByIdAndDomain(ITrueCodeContext context)
        {
            Console.WriteLine("Введите Id пользователя:");
            Guid.TryParse(Console.ReadLine(), out Guid userId);
            //можно вечный цикл или ещё кучу других вариантов обработки
            if (userId == Guid.Empty) throw new Exception("Введён не распозноваемый формат идентификатора пользователя!");
            Console.WriteLine("Введите домен пользователя:");
            var domain = Console.ReadLine();
            //по Id и domain стоит уникальный ключ, так что точно не будет больше одного
            var user = context.Users.Include(b => b.Tags).FirstOrDefault(a => a.UserId == userId && a.Domain == domain);
            Console.WriteLine(user != null ? user.ToString() : "пользователь не найден!");
        }
    }
}
