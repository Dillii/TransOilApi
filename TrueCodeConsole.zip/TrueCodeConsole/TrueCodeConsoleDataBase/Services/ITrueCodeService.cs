﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrueCodeConsoleDataBase.DataBase;

namespace TrueCodeConsoleDataBase.Services
{
    public interface ITrueCodeService
    {
        void GetAllUsersWithTagValue(ITrueCodeContext dbContext);
        void GetAllUsersInDomain(ITrueCodeContext dbContext);
        void GetUserByIdAndDomain(ITrueCodeContext context);

    }
}
