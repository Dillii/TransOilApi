﻿// See https://aka.ms/new-console-template for more information
using Microsoft.Extensions.DependencyInjection;
using TrueCodeConsoleDataBase;
using TrueCodeConsoleDataBase.DataBase;
using TrueCodeConsoleDataBase.DataBase.Models;
using TrueCodeConsoleDataBase.Services;

//С этой задачей вообще встал в ступор ибо изначально решил что первая задача нужна для заполнения данных этой, но прочитав много раз ТЗ пришёл к выводу что это не так.
// так же так и не смог понять зачем вам нужен класс TagToUser  так как его EntityFrameWork генерирует сам... отсюда долго думал зачем в классе User поле List<TagToUser>? Tags { get; set; } - так и не смог придумать ему применение
// И да - в ТЗ написано - выбрать, но так как далее вообще не было понятно что делать с данными, я вместо передачи решил выводить на консоль (переделать это вопрос пары минут так что думаю это не критично)

var provider = StartUp.Init();

var dbContext = provider.GetService<ITrueCodeContext>();
var trueCodeService = provider.GetService<ITrueCodeService>();
if (dbContext != null && trueCodeService != null)
{
    foreach (var data in dbContext.Users)
    {
        Console.WriteLine(data.ToString());
    }
    foreach (var data in dbContext.Tags)
    {
        Console.WriteLine(data.ToString());
    }
    int state = 0;
    while (state != 4)
    {
        Console.WriteLine("Выберете действие:");
        Console.WriteLine("0 - Загрузка данных.\n 1 - Поиск пользователя по его Id и Domain.\n 2 - Поиск всех пользователей одного Domain, используя pagination.\n 3 - Поиск всех пользователей по значению тега и Domain. \n 4 - Выход из приложения");
        int.TryParse(Console.ReadLine(), out state);
        StateMachine(state, dbContext, trueCodeService);
    }
}
else
    Console.WriteLine("Не удалось загрузить один из базовых сервисов!");
Console.WriteLine("Выходим из приложения");
Console.ReadLine();






void StateMachine(int state, ITrueCodeContext dbContext, ITrueCodeService trueCodeService)
{
    switch (state)
    {
        case 0:
            AddSomeData(dbContext);
            break;
        case 1:
            trueCodeService.GetUserByIdAndDomain(dbContext);
            break;
        case 2:
            trueCodeService.GetAllUsersInDomain(dbContext);
            break;
        case 3:
            trueCodeService.GetAllUsersWithTagValue(dbContext);
            break;
        case 4:
            //тут мы выходим
            break;
        default:
            Console.WriteLine("Ошибка ввода!  Повторите попытку!");
            break;
    }
}





void AddSomeData(ITrueCodeContext context)
{
    int i = 0;
    List<User> users = new List<User>();
    List<Tag> tags = new List<Tag>();
    while (i < 500)
    {
        var tag1 = new Tag()
        {
            Domain = "MyDomain " + i % 10,
            TagId = Guid.NewGuid(),
            Value = "Опытный программист " + i % 10
        };
        var tag2 = new Tag()
        {
            Domain = "MyDomain " + i,
            TagId = Guid.NewGuid(),
            Value = "Но бесполезный " + i % 10
        };
        var tag3 = new Tag()
        {
            Domain = "HisDomain",
            TagId = Guid.NewGuid(),
            Value = "Системный диванный аналитик " + i % 10
        };
        var mickle = new User()
        {
            UserId = Guid.NewGuid(),
            Name = "Миша " + i % 10,
            Domain = "MyDomain " + i % 10,
            Tags = new List<Tag> { tag1, tag2 }
        };
        var andy = new User()
        {
            UserId = Guid.NewGuid(),
            Name = "Андрей " + i % 10,
            Domain = "HisDomain " + i % 10,
            Tags = new List<Tag> { tag3 }
        };
        users.AddRange(new List<User>() { mickle, andy });
        tags.AddRange(new List<Tag>() { tag1, tag2, tag3 });
        i++;
    }

    context.Users.AddRange(users);
    context.Tags.AddRange(tags);
    context.SaveChanges();
}










