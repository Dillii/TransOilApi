﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrueCodeConsoleDataBase.DataBase;
using System.Configuration;
using TrueCodeConsoleDataBase.Services;

namespace TrueCodeConsoleDataBase
{
    public static class StartUp
    {
        public static ServiceProvider Init()
        {
            var connectionString = ConfigurationManager.AppSettings["DefaultConnection"];
            var result = new ServiceCollection().AddDbContext<TrueCodeContext>().AddScoped<ITrueCodeContext, TrueCodeContext>().AddScoped<ITrueCodeService, TrueCodeService>().BuildServiceProvider();
            return result;
        }
    }
}
