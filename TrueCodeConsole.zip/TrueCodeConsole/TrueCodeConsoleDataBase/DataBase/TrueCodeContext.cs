﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrueCodeConsoleDataBase.DataBase.Models;

namespace TrueCodeConsoleDataBase.DataBase
{
    public class TrueCodeContext : DbContext, ITrueCodeContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Tag> Tags { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseNpgsql("HOST=localhost;Database=postgres;Username=postgres;Password=postgres;Port=5432;");
        }

        void ITrueCodeContext.SaveChanges()
        {
            this.SaveChanges();
        }
    }
}
