﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrueCodeConsoleDataBase.DataBase.Models
{
    [Index("UserId", "Domain", IsUnique = true)]
    public class User
    {
        [Key]
        public long Id { get; set; }

        public Guid UserId { get; set; }

        [Required]
        public string Name { get; set; } = default!;

        [Required]
        public string Domain { get; set; } = default!;
        public List<Tag>? Tags { get; set; }

        public override string ToString()
        {
            var tags = "";
            if (Tags != null)
                foreach (var tag in Tags)
                {
                    tags += tag.ToString() + "\n";
                }
            var userStr = $"UserId={UserId} Name={Name} Domain={Domain}";
            return String.IsNullOrEmpty(tags) ? userStr : userStr + "\n" + "Tags:\n" + tags;
        }
    }
}
