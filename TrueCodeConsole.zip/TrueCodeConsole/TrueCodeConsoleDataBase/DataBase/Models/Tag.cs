﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrueCodeConsoleDataBase.DataBase.Models
{

    [Index("TagId", "Domain", IsUnique = true)]
    public class Tag
    {
        [Key]
        public long Id { get; set; }

        public Guid TagId { get; set; }

        [Required]
        public string Value { get; set; } = default!;

        [Required]
        public string Domain { get; set; } = default!;


        public List<User>? Users { get; set; }

        public override string ToString()
        {
            return $"TagId={TagId} Value = {Value} Domain={Domain}";
        }
    }
}
